from django.apps import AppConfig


class TezpayConfig(AppConfig):
    name = 'tezpay'
